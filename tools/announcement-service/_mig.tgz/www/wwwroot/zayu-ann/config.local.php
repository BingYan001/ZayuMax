<?php
return [
    'DB_PATH'     => '/www/ann-data/zayu-ann/announcement.sqlite',
    'ADMIN_TOKEN' => 'zym_GN8UWAXp5hGBX_GrKOZteK0nbEAeaAPZxLDKg4SW',
    'TIMEZONE'    => 'Asia/Shanghai',
];
